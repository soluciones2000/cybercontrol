<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr" >
   <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
      
      <meta name="keywords" content="Cyber Control Evolution" />
      <meta name="author" content="Jose Sarmiento" />
      <meta name="description" content="Cyber Control Evolution" />
      <meta name="generator" content="Systems Accouting Advice" />
      <title>Cyber Control Evolution</title>
      <link href="favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
      <link href="http://www.template-joomspirit.com/template-joomla/template-full-screen-5/index.php?option=com_search&amp;format=opensearch" rel="search" title="Search Demo Full screen 5 template by JoomSpirit" type="application/opensearchdescription+xml" />
      <script src="js/mootools-core.js" type="text/javascript"></script>
      <script src="js/core.js" type="text/javascript"></script>
      <script src="js/caption.js" type="text/javascript"></script>
      <script src="js/mootools-more.js" type="text/javascript"></script>
      <script type="text/javascript">
         window.addEvent('load', function() {
         				new JCaption('img.caption');
         			});       
      </script>
      <meta name="robots" content="nofollow" />
      <meta name="googlebot" content="nofollow" />
      <meta name="viewport" content="initial-scale=1" />
      <script type="text/javascript">
         if (typeof jQuery === 'undefined') {
             document.write(unescape("%3Cscript src='js/jquery-181.js' type='text/javascript'%3E%3C/script%3E"));
            }
      </script>
      <script type="text/javascript">
         jQuery.noConflict();
      </script>
      <!--	Google fonts	-->
      <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Nobile" />
      <!-- style sheet links -->
      <link rel="stylesheet" href="css/general.css" type="text/css" />
      <link rel="stylesheet" href="css/main.css" type="text/css"  media="all" />
      <link rel="stylesheet" href="css/nav.css" type="text/css"  media="all"/>
      <link rel="stylesheet" href="css/template.css" type="text/css"  media="all" />
      <link rel="stylesheet" href="css/text-header-white.css" type="text/css"  media="screen" />
      <link rel="stylesheet" href="css/supersized.shutter.css" type="text/css"  media="screen" />
      <link rel="stylesheet" href="css/dynamic.css" type="text/css" media="screen" />
      <link rel="stylesheet" type="text/css" href="css/media_queries.css" media="screen" />
      <link rel="stylesheet" href="css/print.css" type="text/css" media="print" />
      <link rel="stylesheet" type="text/css" href="./css/slick.css">
      <link rel="stylesheet" type="text/css" href="./css/slick-theme.css">
      <script type="text/javascript" src="js/jquery_animate.js"></script>
      <script type="text/javascript" src="js/jquery.easing.min.js"></script>
      <script type="text/javascript" src="js/supersized.3.2.1.js"></script>
      <script type="text/javascript" src="js/theme/supersized.shutter.js"></script>
      <script type="text/javascript">  
         jQuery.noConflict();
         jQuery(function(jQuery){
         jQuery.supersized({        
         slideshow : 1,
         autoplay : 1 ,
         start_slide : 0 ,
         stop_loop : 0 ,
         random : 0 ,
         slide_interval : 5000 ,
         transition : 1 ,
         transition_speed : 600 ,
         pause_hover : 0 ,
         keyboard_nav : 1 ,
         performance	: 1 ,
         image_protect : 1 ,
         image_path : 'images/supersized/',        
         fit_always : 0 ,
         fit_portrait : 0 ,
         fit_landscape : 0 ,
         min_width : 0 ,
         min_height : 0 ,
         vertical_center : 1 ,
         horizontal_center : 1 ,         					
         show_bottombar : 1 ,
         show_slidecounter : 0 ,
         show_imagetitle : 1 ,
         show_playbutton : 1 ,
         show_thumb : 1 ,
         thumbnail_navigation : 0 ,                
         slides : [               
         {image : 'images/51.jpg', title : 'example of image title 01', thumb : 'images/51.jpg', url : ''}     
         ,{image : 'images/10.jpg', title : 'example of image title 02', thumb : 'images/10.jpg', url : ''}  
         ,{image : 'images/41.jpg', title : 'example of image title 02', thumb : 'images/41.jpg', url : ''} 
         ,{image : 'images/21.jpg', title : 'example of image title 03', thumb : 'images/21.jpg', url : ''}     
         		]
         		});
         	});				         		     	
      </script>
      <!--	button for fullscreen	-->
      <script type="text/javascript">
         window.addEvent('domready', function() {         
         	jQuery.noConflict();   
         	jQuery('#close-button').click(function(){       		
         		jQuery('#content-part').toggle(1000);
         		jQuery('#close-button').toggle(50);
         		jQuery('#open-button').toggle(1200);
         		jQuery('.top-content').toggleClass('hide-class');
         		jQuery('.footer').toggle(350);
         		jQuery('#thumb-tray').toggleClass('hide_function');       	  
         	});       	
         	jQuery('#open-button').click(function(){        		
         		jQuery('#content-part').toggle(1000);
         		jQuery('#close-button').toggle(50);
         		jQuery('#open-button').toggle(1200);
         		jQuery('.top-content').toggleClass('hide-class');
         		jQuery('.footer').toggle(350);
         		jQuery('#thumb-tray').toggleClass('hide_function');        	  
         	});	         	
         });
      </script>
      <script type="text/javascript">
         //<![CDATA[
         window.addEvent('domready', function() {            
         	var heightWindow = (document.documentElement.clientHeight);
         	var heightHeader = $('top-site').offsetHeight ; 
         	$('content-part').setStyle('min-height', ( heightWindow - heightHeader ) );         
         });
         //]]>
      </script>
      <script language="JavaScript">
        function muestra_oculta(id){
        if (document.getElementById){ //se obtiene el id
        var el = document.getElementById(id); //se define la variable "el" igual a nuestro div
        el.style.display = (el.style.display == 'none') ? 'block' : 'none'; //damos un atributo display:none que oculta el div
        }
        }
        window.onload = function(){/*hace que se cargue la funci�n lo que predetermina que div estar� oculto hasta llamar a la funci�n nuevamente*/
        muestra_oculta('content-part');/* "contenido_a_mostrar" es el nombre que le dimos al DIV */
        }
      </script>
   </head>
   <body style="font-size:0.70em;background-color:#ffffff;" class="  header-fixed normal-page">
      <header id="top-site" style="background-color : #ffffff98;">
         <div>
            <div id="logo" >
               <div class="logo">
                  <a href="index.php">
                     <p><img src="http://saa.com.ve/proyectos/cyber_web/images/logocy.png" alt="" /></p>
                  </a>
               </div>
            </div>
            <nav id="navigation" class="drop-down" role="navigation" >
               <span class="title_menu">
               <a href="#navigation">menu</a>
               </span>
               <ul class="menu">
                  <li class="item-101 current active"><a href="#" >Inicio</a></li>
                  <li class="item-152"><a href="#" >Nosotros</a></li>
                  <li class="item-108"><a href="#" >Productos</a></li>
                  <!-- <li class="item-142 deeper parent">
                     <a href="#" >Features</a>
                     <ul>
                        <li class="item-119"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=22&amp;Itemid=119" >All features</a></li>
                        <li class="item-120"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=12&amp;Itemid=120" >Flexibility and Simplicity</a></li>
                        <li class="item-121 deeper parent">
                           <a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=16&amp;Itemid=121" >Module positions</a>
                           <ul>
                              <li class="item-122"><a href="#" >Test submenu 001</a></li>
                              <li class="item-123"><a href="#" >Test submenu 002</a></li>
                              <li class="item-124"><a href="#" >Test submenu 003</a></li>
                           </ul>
                        </li>
                        <li class="item-125"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=23&amp;Itemid=125" >Typography</a></li>
                        <li class="item-126"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=11&amp;Itemid=126" >Display your menus</a></li>
                        <li class="item-127"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=14&amp;Itemid=127" >Module class suffix</a></li>
                        <li class="item-128"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=10&amp;Itemid=128" >CSS3 Features</a></li>
                        <li class="item-129"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=21&amp;Itemid=129" >Social icons</a></li>
                        <li class="item-130"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=15&amp;Itemid=130" >Module Google map</a></li>
                        <li class="item-154"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=30&amp;Itemid=154" >Module Supersized 3</a></li>
                        <li class="item-155"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=31&amp;Itemid=155" >Module video</a></li>
                     </ul>
                  </li>-->
                  <!--<li class="item-109 deeper parent">
                     <a href="#" >Color themes</a>
                     <ul>
                        <li class="item-143"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=27&amp;Itemid=143" >Example 01</a></li>
                        <li class="item-144"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=24&amp;Itemid=144" >Example 02</a></li>
                        <li class="item-145"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=article&amp;id=26&amp;Itemid=145" >Example 03</a></li>
                     </ul>
                  </li> -->
                 <!-- <li class="item-110 deeper parent">
                     <a href="#" >Example pages</a>
                     <ul>
                        <li class="item-111"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=categories&amp;id=0&amp;Itemid=111" >List all categories</a></li>
                        <li class="item-112"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=7&amp;Itemid=112" >Category blog</a></li>
                        <li class="item-113"><a href="/template-joomla/template-full-screen-5/index.php?option=com_contact&amp;view=contact&amp;id=1&amp;Itemid=113" >Single contact</a></li>
                        <li class="item-114"><a href="/template-joomla/template-full-screen-5/index.php?option=com_contact&amp;view=categories&amp;id=0&amp;Itemid=114" >List all contact category</a></li>
                        <li class="item-115"><a href="/template-joomla/template-full-screen-5/index.php?option=com_search&amp;view=search&amp;searchword=&amp;Itemid=115" >List search results</a></li>
                        <li class="item-116"><a href="/template-joomla/template-full-screen-5/index.php?option=com_content&amp;view=category&amp;id=2&amp;Itemid=116" >Category list</a></li>
                     </ul>
                  </li> -->
                  <li class="item-153">
                     <a href="#" >Contacto</a>
                     <!-- <ul>
                        <li class="item-118"><a href="http://www.template-joomspirit.com/joomla-template" >Others templates</a></li>
                        <li class="item-117"><a href="http://www.template-joomspirit.com/joomla-template/product/49-template-full-screen-5" >Buy this template</a></li>
                     </ul> -->
                  </li>
               </ul>
            </nav>
            <div class="clr"></div>
            <div id="open-button" style="display:none;"></div>
         </div>
      </header>
      <!-- end of HEADER top-site	-->
      <div id="content-part" class="column-content white5">
      
         <div>
            <div class="content">
               <!--  USER 1, 2, 3 -->
               <!--	END OF USERS TOP	-->				
               <div class="main_component" >
                  <!--  MAIN COMPONENT -->
                  <div id="system-message-container"></div>
                  <div class="item-page ">
                     <div class="imagen_logo">
                    <img src="images/logo_blanco_web.png"/>                    
                    </div>
                     <h2>Cyber Control Evolution</h2>
                     <p>Cyber Control Evolution</p>
                     <p>Cyber Control Evolution</p>
                     <h2>Cyber Control Evolution</h2>
                     <p>Cyber Control Evolution</p>
                     <p>Cyber Control Evolution.</p>
                     <h2>Cyber Control Evolution</h2>
                     <p>Cyber Control Evolution</p>
                  </div>
               </div>
               <!--  USER 4, 5, 6 -->
               <!--	END OF USERS BOTTOM	-->
            </div>
            <!-- end of content	-->
            <div class="clr"></div>
         </div>
         <div class="top-content">
            <nav class="breadcrumb">
            </nav>
         </div>
         <!-- end of top content 		-->	
         
      </div>
      
      <!-- end of content-part	 -->
      <!--	supersize	Thumbnail Navigation  -->
       <div class="globo"><div class="frontal"></div><div class="mapfront"></div><div class="mapback"></div><div class="back"></div></div>
        <div id="close-button3"><a href="#" onclick="muestra_oculta('content-part')">fffff</a></div>
        <section class="regular slider">
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>
            <div>
              <img src="images/patro.png">
            </div>       
       </section>
       
      <footer class="footer " style="background-color : #045782;">
         <div>
            <div class="address">
               <div class="module  ">
                  <p>Cyber Control Evolution<a href="#">Copyright</a> here</p>
               </div>
            </div>
            <!--	SOCIAL LINKS	-->
            <div class="social-links">
               <ul>
                  <li class="google">
                     <div class="g-plusone" data-size="small" data-count="false" ></div>
                  </li>
                  <li><a target="_blank" class="twitter" title="Twitter" href="#"><img src="http://saa.com.ve/proyectos/cyber_web/images/twitter-bird3.png" alt="" /></a></li>
                  <li><a target="_blank" class="facebook" title="Facebook" href="#"><img src="http://saa.com.ve/proyectos/cyber_web/images/facebook-logo.png" alt="" /></a></li>
               </ul>
            </div>
            <!-- 	end of Website icons 		-->			
            <nav class="bottom_menu">
               <div class="module  ">
                  <ul class="menu">
                     <li class="item-131"><a href="#" >item 01</a></li>
                     <li class="item-132"><a href="#" >item 02</a></li>
                     <li class="item-133"><a href="#" >item 03</a></li>
                  </ul>
               </div>
            </nav>
            <div id="search">
               <div class="module  ">
                  <form action="inicio.php" method="post">
                     <div class="search">
                        <label for="mod-search-searchword">Search...</label><input name="searchword" id="mod-search-searchword" maxlength="20"  class="inputbox" type="text" size="20" value="Search..."  onblur="if (this.value=='') this.value='Search...';" onfocus="if (this.value=='Search...') this.value='';" /><input type="image" value="Search" class="button" src="http://saa.com.ve/proyectos/cyber_web/images/searchButton.gif" onclick="this.form.searchword.focus();"/>	<input type="hidden" name="task" value="search" />
                        <input type="hidden" name="option" value="com_search" />
                        <input type="hidden" name="Itemid" value="101" />
                     </div>
                  </form>
               </div>
            </div>
            <div class="clr"></div>
         </div>
      </footer>
      
      <!-- end of footer 	-->
      <div class="js" ><a class="jslink" target="_blank" href="http://www.joomspirit.com" title="">JoomSpirit</a></div>
      <script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
      
  <script src="js/jquery-2.2.0.min.js" type="text/javascript"></script>
  <script src="./js/slick.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).on('ready', function() {
      $(".vertical-center-4").slick({
        dots: true,
        vertical: true,
        centerMode: true,
        slidesToShow: 5,
        slidesToScroll: 5
      });
      $(".vertical-center-3").slick({
        dots: true,
        vertical: true,
        centerMode: true,
        slidesToShow: 5,
        slidesToScroll: 5
      });
      $(".vertical-center-2").slick({
        dots: true,
        vertical: true,
        centerMode: true,
        slidesToShow: 5,
        slidesToScroll: 5
      });
      $(".vertical-center").slick({
        dots: true,
        vertical: true,
        centerMode: true,
      });
      $(".vertical").slick({
        dots: true,
        vertical: true,
        slidesToShow: 5,
        slidesToScroll: 5
      });
      $(".regular").slick({
        dots: true,
        infinite: true,
        slidesToShow: 5,
        slidesToScroll: 5
      });
      $(".center").slick({
        dots: true,
        infinite: true,
        centerMode: true,
        slidesToShow: 5,
        slidesToScroll: 5
      });
      $(".variable").slick({
        dots: true,
        infinite: true,
        variableWidth: true
      });
      $(".lazy").slick({
        lazyLoad: 'ondemand', // ondemand progressive anticipated
        infinite: true
      });
    });
    </script>
   </body>
</html>