 <ul class="nav nav-sidebar">
            <li class="active"><a href="index.php"><i class="fa fa-tasks"></i> Inicio</a></li>
            <li><a href="usuarios"><i class="fa fa-user"></i> Usuarios</a></li>
            <li><a href="publicaciones"><i class="fa fa-files-o"></i> Publicaciones</a></li>
            <li><a href="mensajes"><i class="fa fa-envelope-o"></i> Mensajes</a></li>
            <li><a href="../aplicaciones"><i class="fa fa-envelope-o"></i> Escritorio CCE</a></li>
            <li><a href="configuracion"><i class="fa fa-cog"></i> Configuraci&oacute;n</a></li>
 </ul>