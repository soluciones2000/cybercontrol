<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
         <i class="fa fa-chevron-down"></i>
      </button>
      <a class="navbar-brand" href="aplicaciones"><i class="fa fa-clone"></i> <?php echo SITETITLE; ?></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <form class="navbar-form navbar-right" role="search" method="GET" action="search">
        <div class="input-group">
          <input type="text" class="form-control" name="find" placeholder="<?php echo SAULANG5; ?>">
          <span class="input-group-btn">
            <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
          </span>
        </div><!-- /input-group -->
      </form>

      <ul class="nav navbar-nav navbar-right">

        <li class="active"><a href="aplicaciones"><i class="fa fa-home"></i> <?php echo SAULANG1; ?></a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-envelope-o"></i> <?php echo SAULANG3; ?>
            <?php messagesnoread(); ?>
          </a>

          <ul id="messagesul" class="dropdown-menu">
            <?php messagelistli(); ?>
          </ul>
        </li>
        <li><a href="config"><i class="fa fa-cog"></i> <?php echo SAULANG4; ?></a></li>
        <?php isadmin($_SESSION['ranker']); ?>
        <li><a href="logout"><i class="fa fa-sign-out"></i> <?php echo SAULANG2; ?></a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>