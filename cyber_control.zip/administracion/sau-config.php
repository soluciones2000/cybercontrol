<?php
// -----------------------------------------------------      
//  CCE Panel V.1  Hecho por Ing. Jose Sarmiento
//  http://www.saa.com.ve/                                  
// -----------------------------------------------------       
// Datos del Hosting para la conexion a la base de datos
define('HOST', 'localhost');
define('DBUSER', 'saacom_usuariol');
define('DBPASSWORD', 'Jose27722772');
define('DBNAME', 'saacom_adminuser');
// Nota: Debes de cambiar estos dos, ya que con estos dos generas
// contraseñas mas fuertes, la practica de usar varios tipos de
// hash solo hace lento el funcionamiento del script y es innecesario
// puedes crear mas de este tipo usando cualquier generador alfanumerico
// pero recomiendo este sitio http://randomkeygen.com/
// Complementos para contraseñas
define('SALT', 'd68y1860IauOJJuF48y95T4I0V0HxI1P');
define('PEPER', '3OW1liX0mnue6dA4n9R6a871wJVPU07b');
// Complementos para la verficacion del email, en este caso solo debes de usar uno
// puedes utilizar el mismo sitio de http://randomkeygen.com/ pero puede ser como
// tu quieras.
define('TOKENMAIL', 'eLNN439K14o4f6I7Gd8Ni9kdFR4zZYiU');
// Nombre del sistema, para no tener que estarlo editando siempre
define('SITETITLE', 'Cyber Control Evolution Panel');
// Idioma que se va a querer usar.
// solo se tiene que elegir el numero que es referente a cada idioma.
//
//  Español -> 1
//  English -> 2
//  
define('SAULANGDEF','1');
// Estilo por defecto del sitio, quise ponerlo en la administracion
//
// 1 = CCE Default
// 2 = CCE Blue
// 3 = CCE Black
// 4 = CCE Gray
// 5 = CCE Red
define('SAUSTYLE','1');