<?php
function connectsql()
{
	$con=mysqli_connect("localhost","saacom_usuariol","Jose27722772","saacom_adminuser");
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	return $con;
}
function get_records()
{
    $usuario_sec = $_SESSION['idusuario'];
	$con=connectsql();
	//$records=mysqli_query($con,"SELECT * FROM widget, usuarios WHERE widget.idusuario = usuarios.idusuario order by display_order ASC");
	$records=mysqli_query($con,"SELECT * FROM widget,usuarios WHERE ranker = idranker AND idusuario = '$usuario_sec' order by display_order ASC");
	$all=array();
	while($data=$records->fetch_assoc())
	{
		$all[]=$data;
	}
	return $all;
}
function save_record($id,$order)
{
	$con=connectsql();
	$query="UPDATE widget SET display_order=".$order." WHERE id=".$id;
	if ($con->query($query) === TRUE) {
    //echo "Record updated successfully";
	} else {
    //echo "Error updating record: " . $conn->error;
	}
}
?>
